<?php $__env->startSection('judul_halaman','Data Teknisi'); ?>

<?php $__env->startSection('konten'); ?>


    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area br-6">
            <div class="row">
                <div class="col-md-12">
                    <button class="btn btn-sm btn-primary float-right" data-toggle="modal" data-target="#exampleModal">Add new API</button>
                </div>
            </div>
            <div class="table-responsive mb-4 mt-4">
                <table id="zero-config" class="table table-hover dataTable" style="width: 100%;" role="grid" aria-describedby="zero-config_info">
                    <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Api</th>
                        <th>Link</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $api; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->api_nama); ?></td>
                            <td><a href="<?php echo e(url('')); ?>/<?php echo e($item->api_link); ?>" target="_blank"><?php echo e(url('')); ?>/<?php echo e($item->api_link); ?></a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(url('add-api')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Nama API</label>
                            <input type="text" required name="api_nama" placeholder="Masukkan Nama Api" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Link API</label>
                            <input type="text" required name="api_link" placeholder="Ex: api/user/.." class="form-control">
                        </div>


                </div>
                <div class="modal-footer">
                    <button class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Discard</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\digi-servis\resources\views/api/index.blade.php ENDPATH**/ ?>