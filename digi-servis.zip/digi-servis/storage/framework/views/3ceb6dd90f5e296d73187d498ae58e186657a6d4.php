<?php $__env->startSection('judul_halaman','Data Teknisi'); ?>

<?php $__env->startSection('konten'); ?>



    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area br-6">

            <div class="table-responsive mb-4 mt-4">
                <table id="zero-config" class="table table-hover dataTable" style="width: 100%;" role="grid" aria-describedby="zero-config_info">
                    <thead>
                    <tr>
                        <th>No</th>
                        <th>Foto</th>
                        <th>Nama Teknisi</th>
                        <th>Alamat</th>
                        <th>Nomor HP</th>
                        <th>Deskripsi</th>
                        <th>Sertifikat</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $teknisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><img src="<?php echo e(url('uploads/teknisi')); ?>/<?php echo e($item->teknisi_foto); ?>" alt="Foto tidak ditemukan" width="50px" height="50px"></td>
                            <td><?php echo e($item->teknisi_nama); ?></td>
                            <td><?php echo e($item->teknisi_alamat); ?></td>
                            <td><?php echo e($item->teknisi_hp); ?></td>
                            <td><?php echo e($item->teknisi_deskripsi); ?></td>
                            <td>
                                <?php if($item->teknisi_sertifikat != null): ?>
                                    <a href="#<?php echo e($item->teknisi_sertifikat); ?>">lihat</a>
                                <?php else: ?>
                                    <span class="badge badge-danger badge-sm">tidak ada</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center"><a href="#" onclick="return confirm('Yakin ingin menghapus?')">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x-circle table-cancel"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\digi-servis\resources\views/teknisi/index.blade.php ENDPATH**/ ?>